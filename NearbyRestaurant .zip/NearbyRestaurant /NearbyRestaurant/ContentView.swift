//
//  ContentView.swift
//  RestaurantFinder_upgraded
//
//  Created by YUN NADI OO   on 2025/01/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            // Home
            SearchView()
                .tabItem {
                    Image(systemName: "house")
                    Text("ホーム")
                }

            FavoritesView()
                .tabItem{
                    Image(systemName: "heart.fill")
                    Text("お気に入り")
                }
                  
     
            // Map
            RestaurantMapView()
                .tabItem {
                    Image(systemName: "map")
                    Text("マップ")
                }

            // Account
            UserProfileView()
                .tabItem {
                    Image(systemName: "person")
                    Text("アカウント")
                }
        }
    }
}

#Preview {
    ContentView()
}
