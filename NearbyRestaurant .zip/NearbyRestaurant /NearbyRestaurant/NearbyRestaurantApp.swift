//
//  NearbyRestaurantApp.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//

import SwiftUI

@main
struct NearbyRestaurantApp: App {
    var body: some Scene {
           WindowGroup {
               RootView()
           }
       }
   }
