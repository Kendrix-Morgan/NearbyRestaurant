//
//  ResultsView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//


import SwiftUI

struct ResultsView: View {
    let latitude: Double
    let longitude: Double
    let radius: Int
    let keyword: String?

    @State private var restaurants: [Restaurant] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    @AppStorage("favoriteRestaurants") private var favoriteData: Data = Data()
    @State private var favoriteRestaurants: [Restaurant] = []

    var body: some View {
        VStack {
            if isLoading {
                ProgressView("レストランを読み込み中…")
                    .foregroundStyle(Color.black)
            } else if let errorMessage = errorMessage {
                Text("エラーが発生しました: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
            } else if restaurants.isEmpty {
                Text("レストランが見つかりませんでした。")
                    .font(.title3)
                    .foregroundColor(.gray)
                    .padding(.top, 50)
            } else {
                VStack {
                    Text("検索結果")
                        .font(.system(size: 34))
                        .fontWeight(.bold)

                    List {
                        ForEach(restaurants) { restaurant in
                            HStack {
                                // NavigationLink EXCLUDES the heart icon
                                NavigationLink(destination: DetailsView(restaurant: restaurant)) {
                                    HStack {
                                        AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                                            image.resizable()
                                                .frame(width: 80, height: 80)
                                                .cornerRadius(8)
                                        } placeholder: {
                                            ProgressView()
                                                .frame(width: 80, height: 80)
                                        }

                                        VStack(alignment: .leading) {
                                            Text(restaurant.name)
                                                .font(.headline)

                                            Text(restaurant.address)
                                                .font(.subheadline)
                                                .foregroundColor(.gray)

                                            Text("⭐️ \(restaurant.access)")
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                    }
                                }
                                .buttonStyle(PlainButtonStyle())

                                Spacer()

                                // Favorite button - OUTSIDE the NavigationLink
                                Button(action: {
                                    toggleFavorite(restaurant)
                                }) {
                                    Image(systemName: favoriteRestaurants.contains(where: { $0.id == restaurant.id }) ? "heart.fill" : "heart")
                                        .foregroundColor(.pink)
                                }
                                .buttonStyle(BorderlessButtonStyle())
                            }
                            .padding(.vertical, 8)
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
        }
        .onAppear {
            loadFavorites()
            fetchRestaurants()
        }
    }

    private func fetchRestaurants() {
        ApiClient.shared.fetchRestaurants(latitude: latitude, longitude: longitude, radius: radius, keyword: keyword) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    self.restaurants = data
                    self.isLoading = false
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }

    private func toggleFavorite(_ restaurant: Restaurant) {
        if favoriteRestaurants.contains(where: { $0.id == restaurant.id }) {
            favoriteRestaurants.removeAll { $0.id == restaurant.id }
        } else {
            favoriteRestaurants.append(restaurant)
        }

        if let encoded = try? JSONEncoder().encode(favoriteRestaurants) {
            favoriteData = encoded
        }
    }

    private func loadFavorites() {
        if let decoded = try? JSONDecoder().decode([Restaurant].self, from: favoriteData) {
            favoriteRestaurants = decoded
        }
    }
}
