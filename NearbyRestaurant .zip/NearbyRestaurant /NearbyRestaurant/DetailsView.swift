//
//  DetailsView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//

import SwiftUI

struct DetailsView: View {
    let restaurant: Restaurant

    @State private var showReturnAlert = false

    var body: some View {
        VStack {
            Text("詳しい情報")
                .font(.system(size: 34))
                .fontWeight(.bold)

            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                        image.resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(height: 200)
                            .cornerRadius(12)
                    } placeholder: {
                        ProgressView()
                    }

                    Text(restaurant.name)
                        .font(.largeTitle)
                        .bold()

                    HStack(alignment: .top) {
                        Text("\t 住所：")
                            .fontWeight(.bold)

                        VStack(alignment: .leading, spacing: 4) {
                            Text(restaurant.address)
                        }
                    }

                    HStack(alignment: .top) {
                        Text("営業時間：")
                            .fontWeight(.bold)

                        VStack(alignment: .leading, spacing: 4) {
                            Text(restaurant.businessHours)
                        }
                    }
                    HStack{
                        Spacer()
                        Button(action: {
                            showReturnAlert = true
                        }) {
                            VStack {
                                Image("map")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 80)
                                Text("マップで表示")
                                    .foregroundColor(.blue)
                            }
                            
                        }
                        
                        .alert(isPresented: $showReturnAlert) {
                            Alert(
                                title: Text("マップを開きますか？"),
                                message: Text("Appleマップが開きます。\n戻る時はアプリを再度タップしてください。"),
                                primaryButton: .default(Text("開く"), action: {
                                    openInMaps()
                                }),
                                secondaryButton: .cancel(Text("キャンセル"))
                            )
                        }//alert
                        
                    }.padding(.top,20)
                }
                .padding()
            }
        }
    }

    private func openInMaps() {
        let encodedName = restaurant.name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let nameOnlyURLString = "maps://?q=\(encodedName)"
        if let nameOnlyURL = URL(string: nameOnlyURLString),
           UIApplication.shared.canOpenURL(nameOnlyURL) {
            UIApplication.shared.open(nameOnlyURL)
        }
    }
}
