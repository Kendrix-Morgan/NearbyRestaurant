//
//  SearchView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/20.
//

import SwiftUI
import CoreLocation

struct SearchView: View {
    @State private var latitude: Double = 0.0
    @State private var longitude: Double = 0.0
    @StateObject private var locationManager = LocationManager()

    @State private var recommendedRestaurants: [Restaurant] = []
    @State private var isLoadingRecommended = true
    @State private var showSearchSheet = false
    @State private var selectedKeyword: String = ""
    @State private var navigateToResults = false

    var body: some View {
        NavigationStack {
            VStack {
                // Search Icon Button
                HStack {
                    Button(action: {
                        selectedKeyword = ""
                        showSearchSheet = true
                    }) {
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)
                            Text("検索する")
                                .foregroundColor(.gray)
                            Spacer()
                        }
                        .padding(.horizontal)
                        .frame(height: 50)
                        .background(Color(.systemGray5))
                        .clipShape(RoundedRectangle(cornerRadius: 19))
                    }
                }
                .padding(.horizontal)
                .padding(.top, 25)

                //  Category scroll
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 28) {
                        ForEach(PhotoData.photos) { photo in
                            Button(action: {
                                selectedKeyword = photo.label
                                navigateToResults = true
                            }) {
                                VStack(spacing: 18) {
                                    Image(photo.imageName)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 78, height: 66)

                                    Text(photo.label)
                                        .font(.headline)
                                        .foregroundColor(.primary)
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top)
                }

                //  Recommended Section
                Text("\(locationManager.cityName.isEmpty ? "あなたの地域" : locationManager.cityName)のお勧めレストラン")
                    .font(.title2)
                    .bold()
                    .padding(.top, 30)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 10)

                if isLoadingRecommended {
                    VStack {
                        ProgressView("お勧めレストランを読み込み中…")
                    }
                    .frame(minHeight: 150, maxHeight: 650)
                } else {
                    if recommendedRestaurants.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "exclamationmark.triangle")
                                .font(.system(size: 40))
                                .foregroundColor(.gray)
                            Text("見つかりませんでした")
                                .font(.headline)
                                .foregroundColor(.gray)
                            Text("周辺のレストラン情報が取得できませんでした。")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity, maxHeight: 550)
                    } else {
                        ScrollView {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                                ForEach(recommendedRestaurants) { restaurant in
                                    NavigationLink(destination: DetailsView(restaurant: restaurant)) {
                                        VStack(alignment: .leading) {
                                            AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                                                image.resizable()
                                                    .scaledToFill()
                                                    .frame(width: 170, height: 130)
                                                    .cornerRadius(8)
                                            } placeholder: {
                                                ProgressView()
                                            }
                                            Text(restaurant.name)
                                                .font(.subheadline)
                                                .fontWeight(.bold)
                                                .foregroundColor(.primary)
                                                .lineLimit(2)
                                        }
                                        .frame(height: 150)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        .frame(height: 400)
                    }
                }
            }
            .padding(.bottom)
            .onAppear {
                locationManager.startUpdatingLocation()
            }
            .onChange(of: locationManager.latitude) {
                if locationManager.latitude != 0.0 && locationManager.longitude != 0.0 {
                    fetchRecommendedRestaurants()
                    latitude = locationManager.latitude
                    longitude = locationManager.longitude
                }
            }
            .navigationDestination(isPresented: $navigateToResults) {
                ResultsView(latitude: latitude, longitude: longitude, radius: 5, keyword: selectedKeyword)
            }
            .fullScreenCover(isPresented: $showSearchSheet) {
                FullScreenSearchSheet(
                    showSheet: $showSearchSheet,
                    latitude: latitude,
                    longitude: longitude,
                    defaultKeyword: selectedKeyword
                )
            }
        }
    }

    private func fetchRecommendedRestaurants() {
        ApiClient.shared.fetchRecommendedRestaurants(latitude: locationManager.latitude, longitude: locationManager.longitude) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    recommendedRestaurants = data
                    isLoadingRecommended = false
                case .failure(let error):
                    print("Error fetching recommended restaurants: \(error.localizedDescription)")
                    isLoadingRecommended = false
                }
            }
        }
    }
}

//  FullScreenSearchSheet.swift
struct FullScreenSearchSheet: View {
    @Binding var showSheet: Bool
    var latitude: Double
    var longitude: Double
    var defaultKeyword: String

    @State private var keyword: String = ""
    @State private var radius: Int = 1

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // 🔍 Search bar + Cancel
                HStack {
                    TextField("Search", text: $keyword)
                        .padding(10)
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .padding(.leading)

                    Button("Cancel") {
                        showSheet = false
                    }
                    .foregroundColor(.white)
                    .padding(.trailing)
                }
                .padding(.top)

               
                Picker("範囲を選ぶ", selection: $radius) {
                    ForEach(1...5, id: \.self) { distance in
                        Text("\(distance) km").tag(distance)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)

                // 🔎 Search Button
                NavigationLink(
                    destination: ResultsView(latitude: latitude, longitude: longitude, radius: radius, keyword: keyword)
                ) {
                    Text("検索する")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                .padding(.top)

                Spacer()
            }
            .onAppear {
                keyword = defaultKeyword
            }
            .background(Color.black.ignoresSafeArea())
            .navigationBarHidden(true)
        }
        .preferredColorScheme(.dark)
    }
}

#Preview {
    SearchView()
}

