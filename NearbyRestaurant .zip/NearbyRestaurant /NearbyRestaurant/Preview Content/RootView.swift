//
//  RootView.swift
//  NearbyRestaurant
//
//  Created by YUN NADI OO   on 2025/06/02.
//

import SwiftUI

struct RootView: View {
    @AppStorage("isLoggedIn") private var isLoggedIn = false

    var body: some View {
        if isLoggedIn {
            ContentView() // ← this is your full app with tabs
        } else {
            Welcome() // ← this is your welcome/create account screen
        }
    }
}
