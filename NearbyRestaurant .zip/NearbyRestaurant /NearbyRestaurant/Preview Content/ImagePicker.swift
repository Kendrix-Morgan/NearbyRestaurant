//
//  ImagePicker.swift
//  NearbyRestaurant
//
//  Created by YUN NADI OO on 2025/05/30.
//

import SwiftUI
import UIKit

// SwiftUIから写真を選ぶためのビュー
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage? //  選ばれた画像を保持するバインディング変数

    func makeCoordinator() -> Coordinator {
        Coordinator(self) // コーディネーターを作成
    }

    // 画像が選ばれた時の処理などを担当
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        //  ユーザーが画像を選んだときに呼ばれる
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage //  選ばれた画像をバインディングに代入
            }
            picker.dismiss(animated: true) // ピッカーを閉じる
        }
    }

    //  UIImagePickerControllerを作成
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator //  デリゲートをコーディネーターに設定
        return picker
    }

    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
}
