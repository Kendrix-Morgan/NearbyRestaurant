//
//  RestaurantMapView.swift
//  NearbyRestaurant
//
//  Created by YUN NADI OO on 2025/05/30.
//

import SwiftUI
import MapKit

struct RestaurantMapView: View {
    // 初期表示する地図の範囲（東京都付近）
    @State private var cameraPosition = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 35.6804, longitude: 139.7690),
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
    )

    @State private var restaurants: [Restaurant] = [] // 表示するレストランリスト
    @State private var isLoading = true // 読み込み中フラグ

    var body: some View {
        ZStack {
            // 地図ビュー（ピンと画像付き）
            Map(position: $cameraPosition) {
                ForEach(restaurants) { restaurant in
                    Annotation("", coordinate: CLLocationCoordinate2D(latitude: restaurant.latitude, longitude: restaurant.longitude)) {
                        // 📍 各レストランの画像付きカスタムピン
                        Button(action: {
                            openInMaps(for: restaurant) // Appleマップで開く
                        }) {
                            VStack(spacing: 4) {
                                AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                                    image.resizable()
                                } placeholder: {
                                    Color.gray
                                }
                                .frame(width: 40, height: 40)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white, lineWidth: 2))

                                Text(restaurant.name)
                                    .font(.caption2)
                                    .foregroundColor(.black)
                                    .padding(4)
                                    .background(Color.white.opacity(0.8))
                                    .cornerRadius(6)
                            }
                        }
                    }
                }
            }
            .edgesIgnoringSafeArea(.all)

            // ローディング表示
            if isLoading {
                ProgressView("地図にレストランを読み込み中…")
                    .padding()
                    .background(.thinMaterial)
                    .cornerRadius(10)
            }
        }
        .onAppear {
            fetchRestaurants() // 表示時にAPIからレストランを取得
        }
    }

    // APIからおすすめレストランを取得
    private func fetchRestaurants() {
        ApiClient.shared.fetchRecommendedRestaurants(
            latitude: cameraPosition.region?.center.latitude ?? 35.6804,
            longitude: cameraPosition.region?.center.longitude ?? 139.7690
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    self.restaurants = data
                    self.isLoading = false
                case .failure(let error):
                    print("Map API error: \(error.localizedDescription)")
                    self.isLoading = false
                }
            }
        }
    }

    // Appleマップで開く（名前で検索）
    private func openInMaps(for restaurant: Restaurant) {
        let encodedName = restaurant.name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let nameOnlyURLString = "maps://?q=\(encodedName)"
        if let nameOnlyURL = URL(string: nameOnlyURLString),
           UIApplication.shared.canOpenURL(nameOnlyURL) {
            UIApplication.shared.open(nameOnlyURL)
        }
    }
}
