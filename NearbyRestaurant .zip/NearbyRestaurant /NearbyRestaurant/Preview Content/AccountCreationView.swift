//
//  AccountCreationView.swift
//  NearbyRestaurant
//
//  Created by YUN NADI OO   on 2025/05/28.
//

import SwiftUI

struct AccountCreationView: View {
    @AppStorage("userName") var userName = ""
    @AppStorage("userPhone") var userPhone = ""
    @AppStorage("userEmail") var userEmail = ""
    @AppStorage("userAddress") var userAddress = ""
    @AppStorage("isLoggedIn") var isLoggedIn = false

    @State private var name = ""
    @State private var phone = ""
    @State private var email = ""
    @State private var address = ""

    @State private var showProfile = false

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("アカウント作成")) {
                    TextField("名前", text: $name)
                    TextField("電話番号", text: $phone)
                    TextField("メール", text: $email)
                    TextField("住所", text: $address)
                }

                Button("アカウントを作成") {
                    userName = name
                    userPhone = phone
                    userEmail = email
                    userAddress = address
                    isLoggedIn = true
                }
                .disabled(name.isEmpty || phone.isEmpty || email.isEmpty || address.isEmpty)
            }
            .navigationDestination(isPresented: $showProfile) {
               ContentView()
            }
            .navigationTitle("Create Account")
        }
    }
}


#Preview {
    AccountCreationView()
}
