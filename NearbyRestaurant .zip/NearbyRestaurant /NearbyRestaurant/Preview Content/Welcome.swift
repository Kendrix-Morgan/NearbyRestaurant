//
//  Welcome.swift
//  NearbyRestaurant
//
//  Created by YUN NADI OO   on 2025/05/28.
//
import SwiftUI

struct Welcome: View {
    @State private var goToCreate = false

    var body: some View {
        NavigationStack {
            ZStack {
                Image("bg")
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width,
                           height: UIScreen.main.bounds.height)
                    .ignoresSafeArea()
                    .padding(.leading,85)

                // ✨ Foreground Content
                VStack(spacing: 30) {
                    Image("applogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200)

                    Text("ようこそ")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
       
                    Button(action: {
                        goToCreate = true
                    }){
                        Text("新規アカウント作成")
                            .fontWeight(.semibold)
                            .foregroundColor(Color.black)
                            .frame(maxWidth: 330)
                            .padding()
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(Color.black, lineWidth: 2)
                            )
                    }
                   
                    .padding(25)
                }
            }
            .navigationDestination(isPresented: $goToCreate) {
                AccountCreationView()
            }
        }
    }
}

#Preview {
    Welcome()
}
