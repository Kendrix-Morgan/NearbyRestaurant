//
//  FavoritesView.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/05/29.
//

import SwiftUI

struct FavoritesView: View {
    // お気に入りデータを端末に保存・読み込み
    @AppStorage("favoriteRestaurants") private var favoriteData: Data = Data()
    @State private var favoriteRestaurants: [Restaurant] = []

    var body: some View {
        NavigationView {
            // お気に入りが空の場合
            if favoriteRestaurants.isEmpty {
                VStack(spacing: 20) {
                    Image(systemName: "heart.slash")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.gray)

                    Text("お気に入りがまだありません")
                        .font(.title3)
                        .foregroundColor(.gray)
                }
                .navigationTitle("お気に入り")
            } else {
                // ❤️ お気に入りリストがある場合
                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(favoriteRestaurants) { restaurant in
                            NavigationLink(destination: DetailsView(restaurant: restaurant)) {
                                HStack {
                                    // 🍽 店の画像
                                    AsyncImage(url: URL(string: restaurant.imageURL)) { image in
                                        image.resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 80, height: 80)
                                            .cornerRadius(8)
                                    } placeholder: {
                                        ProgressView()
                                            .frame(width: 80, height: 80)
                                    }

                                    // 📋 店の名前と住所
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(restaurant.name)
                                            .font(.headline)

                                        Text(restaurant.address)
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                    }

                                    Spacer()
                                }
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(12)
                            }
                        }
                    }
                    .padding()
                }
                .navigationTitle("お気に入り")
            }
        }
        .onAppear(perform: loadFavorites) // 画面が表示されたときにお気に入りを読み込む
    }

    //  保存されているお気に入りを読み込んで表示する
    private func loadFavorites() {
        guard let decoded = try? JSONDecoder().decode([Restaurant].self, from: favoriteData) else {
            favoriteRestaurants = []
            return
        }
        favoriteRestaurants = decoded
    }
}
