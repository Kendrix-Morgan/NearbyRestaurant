//  UserProfileView.swift
//  NearbyRestaurant
//
//  Created by YUN NADI OO on 2025/05/29.
//

import SwiftUI

struct UserProfileView: View {
    @State private var isEditing = false
    @AppStorage("userName") private var name: String = ""
    @AppStorage("userPhone") private var phone: String = ""
    @AppStorage("userEmail") private var email: String = ""
    @AppStorage("userAddress") private var address: String = ""
    @AppStorage("isLoggedIn") private var isLoggedIn: Bool = true

    @State private var image: Image? = nil
    @State private var showImagePicker = false
    @State private var inputImage: UIImage?
    @State private var phoneError = false
    @State private var showEmptyAlert = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    Spacer().frame(height: 30)

                    // Profile Image
                    ZStack {
                        if let selectedImage = image {
                            selectedImage
                                .resizable()
                                .scaledToFill()
                                .frame(width: 150, height: 150)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.gray, lineWidth: 2))
                        } else {
                            Image(systemName: "person.crop.circle.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .foregroundColor(.gray)
                        }
                    }

                    if isEditing {
                        Button("写真を追加") {
                            showImagePicker = true
                        }
                        .padding(.top, 8)
                        .font(.body.bold())
                        .foregroundColor(.white)
                        .padding(.horizontal, 30)
                        .padding(.vertical, 8)
                        .background(Color(.darkGray))
                        .clipShape(Capsule())
                    }

                    Spacer().frame(height: 40)

                    // 📝 Form Fields
                    VStack(spacing: 16) {
                        Group {
                            TextField("名前", text: $name)
                                .frame(maxWidth: .infinity, alignment: .leading)

                            TextField("電話番号", text: $phone)
                                .keyboardType(.numberPad)
                                .onChange(of: phone) { old, new in
                                    let filtered = new.filter { $0.isNumber }
                                    phoneError = (filtered != new)
                                    phone = filtered
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)

                            TextField("メールアドレス", text: $email)
                                .frame(maxWidth: .infinity, alignment: .leading)

                            TextField("住所", text: $address)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                        .disabled(!isEditing)

                        if phoneError {
                            Text("数字のみ入力してください")
                                .font(.caption)
                                .foregroundColor(.red)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }

                    // Delete Button
                    if isEditing {
                        Button("アカウントを削除する") {
                            deleteProfile()
                        }
                        .foregroundColor(.red)
                        .padding(.top, 20)
                    }

                    Spacer()
                }
                .padding()
            }
            .navigationTitle("アカウント")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(isEditing ? "完了" : "編集") {
                        if isEditing {
                            saveProfile()

                            if name.isEmpty && phone.isEmpty && email.isEmpty && address.isEmpty {
                                showEmptyAlert = true
                                return
                            }
                        }
                        isEditing.toggle()
                    }
                }
            }
            .alert("情報がすべて未入力です", isPresented: $showEmptyAlert) {
                Button("キャンセル", role: .cancel) {}
                Button("はい", role: .destructive) {
                    isLoggedIn = false
                }
            } message: {
                Text("すべての情報が空になっています。新しくアカウントを作成しますか？")
            }
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(image: $inputImage)
        }
        .onChange(of: inputImage) { _, _ in
            loadImage()
        }
        .onAppear {
            loadSavedImage()
        }
    }

    func loadImage() {
        guard let inputImage = inputImage else { return }
        image = Image(uiImage: inputImage)

        if let data = inputImage.jpegData(compressionQuality: 0.8) {
            UserDefaults.standard.set(data, forKey: "userProfileImage")
        }
    }

    func loadSavedImage() {
        if let data = UserDefaults.standard.data(forKey: "userProfileImage"),
           let uiImage = UIImage(data: data) {
            self.image = Image(uiImage: uiImage)
        }
    }

    func saveProfile() {
        UserDefaults.standard.set(name, forKey: "userName")
        UserDefaults.standard.set(phone, forKey: "userPhone")
        UserDefaults.standard.set(email, forKey: "userEmail")
        UserDefaults.standard.set(address, forKey: "userAddress")
    }

    func deleteProfile() {
        name = ""
        phone = ""
        email = ""
        address = ""
        image = nil
        inputImage = nil

        UserDefaults.standard.removeObject(forKey: "userName")
        UserDefaults.standard.removeObject(forKey: "userPhone")
        UserDefaults.standard.removeObject(forKey: "userEmail")
        UserDefaults.standard.removeObject(forKey: "userAddress")
        UserDefaults.standard.removeObject(forKey: "favoriteRestaurants")
        UserDefaults.standard.removeObject(forKey: "userProfileImage")

        isLoggedIn = false
    }
}

#Preview {
    UserProfileView()
}
