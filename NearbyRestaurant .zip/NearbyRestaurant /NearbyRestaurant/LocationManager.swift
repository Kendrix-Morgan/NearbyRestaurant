//
//  LocationManager.swift
//  NearbyRestaurant
//
//  Created by Kendrix on 2025/01/28.
//
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()
    private let geocoder = CLGeocoder()

    // SwiftUIに通知するための変数（位置情報やエラーなど）
    @Published var latitude: Double = 0.0
    @Published var longitude: Double = 0.0
    @Published var cityName: String = ""
    @Published var locationError: String?

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization() // 位置情報の利用許可をユーザーにリクエスト
        locationManager.desiredAccuracy = kCLLocationAccuracyBest // できるだけ正確な位置情報を取得
    }

    func startUpdatingLocation() {
        locationManager.startUpdatingLocation() // 位置情報の更新を開始
    }

    func stopUpdatingLocation() {
        locationManager.stopUpdatingLocation() // 位置情報の更新を停止（バッテリー節約）
    }

    // 位置情報が更新されたときに呼ばれるメソッド
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        latitude = location.coordinate.latitude
        longitude = location.coordinate.longitude

        // 座標から市区町村名を取得（逆ジオコーディング）
        let locale = Locale(identifier: "ja_JP")
        geocoder.reverseGeocodeLocation(location, preferredLocale: locale) { [weak self] placemarks, error in
            if let error = error {
                self?.locationError = error.localizedDescription
                return
            }

            if let placemark = placemarks?.first {
                self?.cityName = placemark.locality ?? ""
            }
        }
    }

    // ❌位置情報の取得に失敗したときに呼ばれる
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationError = error.localizedDescription
    }
}
