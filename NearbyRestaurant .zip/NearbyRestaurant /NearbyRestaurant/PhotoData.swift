//
//  PhotoData.swift
//  Location test
//
//  Created by Kendrix on 2025/01/21.
//

import Foundation

struct Photo: Identifiable {
    let id = UUID()
    let imageName: String
    let label: String
}

struct PhotoData {
    static let photos: [Photo] = [
        Photo(imageName: "korean", label: "韓国"),
        Photo(imageName: "thai", label: "タイ"),
        Photo(imageName: "indian", label: "インド"),
        Photo(imageName: "desserts", label: "ケーキ"),
        Photo(imageName: "cafe", label: "カフェ"),
        Photo(imageName: "ice-cream", label: "アイス"),
        Photo(imageName: "healthy", label: "野菜"),
        Photo(imageName: "pizza", label: "ピザ")
        
    ]
}
