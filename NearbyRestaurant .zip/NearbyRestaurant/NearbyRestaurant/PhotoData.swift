//
//  PhotoData.swift
//  Location test
//
//  Created by Kendrix on 2025/01/21.
//

import Foundation

struct Photo: Identifiable {
    let id = UUID()
    let imageName: String
    let label: String
}

struct PhotoData {
    static let photos: [Photo] = [
        Photo(imageName: "korean", label: "Korea"),
        Photo(imageName: "thai", label: "Thai"),
        Photo(imageName: "indian", label: "Indian"),
        Photo(imageName: "desserts", label: "Cakes"),
        Photo(imageName: "cafe", label: "Cafe"),
        Photo(imageName: "ice-cream", label: "Ice Cream"),
        Photo(imageName: "healthy", label: "Healthy"),
        Photo(imageName: "pizza", label: "Pizza")
        
    ]
}
